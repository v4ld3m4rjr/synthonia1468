export default function Page(){return <main style={padding:24}>ai ok</main>}
