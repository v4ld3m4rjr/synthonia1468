export default function RootLayout({ children }:{ children: React.ReactNode }){
  return (
    <html lang="pt-BR">
      <body style={{background:'#0D0E12',color:'#E6E6E6'}}>{children}</body>
    </html>
  )
}
