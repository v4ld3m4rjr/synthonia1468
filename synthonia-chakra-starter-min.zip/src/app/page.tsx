import Link from 'next/link'
export default function Home(){
  return <main style={{padding:24}}><Link href="/dashboard">Abrir Dashboard</Link></main>
}
