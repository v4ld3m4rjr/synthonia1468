# SynthonIA Chakra — Clean Starter (Netlify + Next 14)

Data: 2025-08-12

## Passo a passo (sem terminal)
1. Crie um repositório **novo** no GitHub.
2. Faça upload de **todos** os arquivos desta pasta.
3. No Netlify, conecte o repo.
   - **Build command**: `npm run build`
   - **Publish directory**: deixe **vazio**
4. Em *Environment variables*, adicione:
   - `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` (opcional por enquanto)
   - `OPENAI_API_KEY` (opcional)
5. Clique em **Retry deploy → Clear cache and deploy**.

Se aparecer algo como `/(dashboard)/page`, significa que existe uma pasta **(dashboard)**. Este starter **não** tem `/(dashboard)`, só `/dashboard`.
