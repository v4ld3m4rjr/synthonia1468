export default function Page(){
  return <section className="p-6"><div className="card">rehab ok</div></section>
}
