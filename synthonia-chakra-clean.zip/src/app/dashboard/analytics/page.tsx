export default function Page(){
  return <section className="p-6"><div className="card">analytics ok</div></section>
}
