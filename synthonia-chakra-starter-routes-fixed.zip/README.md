# SynthonIA Chakra — Starter Kit (rotas corrigidas)

Data: 2025-08-11

- Rotas em `/dashboard/*` (sem grupos com parênteses).
- `typedRoutes` desativado no `next.config.js` para evitar conflitos de tipos.
- `netlify.toml` sem `publish` (plugin do Next lida com a saída).

## Estrutura
(ver diretórios)
