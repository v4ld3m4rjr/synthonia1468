export default function TreinosPage() {
  return (
    <section className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Treinos</h2>
      <div className="card">Cadastro rápido, upload CSV, tonelagem e densidade.</div>
    </section>
  )
}
