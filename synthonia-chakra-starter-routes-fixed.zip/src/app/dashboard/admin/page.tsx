export default function AdminPage() {
  return (
    <section className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Admin</h2>
      <div className="card">Métricas de uso: telas, horários, eventos (apenas admin).</div>
    </section>
  )
}
