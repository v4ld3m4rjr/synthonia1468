export default function RehabPage() {
  return (
    <section className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Rehab</h2>
      <div className="card">Planos de reabilitação e evolução de dor.</div>
    </section>
  )
}
