export default function RecoveryPage() {
  return (
    <section className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Recovery</h2>
      <div className="card">Formulário diário (sono, fadiga, dor, estresse, humor, PRS, TQR) + KPI IIERP.</div>
    </section>
  )
}
