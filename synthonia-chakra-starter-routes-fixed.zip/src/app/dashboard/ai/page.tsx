export default function AiPage() {
  return (
    <section className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Ai</h2>
      <div className="card">Pergunte aos seus dados + insights abaixo dos gráficos.</div>
    </section>
  )
}
