/// <reference types="next" />
/// <reference types="next/image-types/global" />
