export default function RehabPage() {
  return (
    <section className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Rehabilitation</h2>
      <div className="card">Planos e observações por paciente; evolução de dor.</div>
    </section>
  )
}
