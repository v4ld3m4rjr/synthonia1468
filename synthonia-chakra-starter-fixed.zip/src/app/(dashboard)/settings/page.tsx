export default function SettingsPage() {
  return (
    <section className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Configurações</h2>
      <div className="card">Perfil, vínculos, notificações e privacidade.</div>
    </section>
  )
}
