export default function AdminPage() {
  return (
    <section className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Admin</h2>
      <div className="card">Métricas de uso: usuários ativos, telas mais vistas, horários, eventos.</div>
    </section>
  )
}
