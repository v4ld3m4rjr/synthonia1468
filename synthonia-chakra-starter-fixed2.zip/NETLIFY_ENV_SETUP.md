# Configuração de variáveis de ambiente (Netlify + Local)

> **Nunca** versione chaves reais. Use o painel do Netlify para produção e `.env.local` somente na sua máquina.

## Netlify (produção)
No painel do site → *Site settings* → *Build & deploy* → *Environment* → **Add environment variables**:

- `NEXT_PUBLIC_SUPABASE_URL` = <COLE_AQUI_SUA_URL_DO_SUPABASE>
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` = <COLE_AQUI_SUA_ANON_PUBLIC_KEY_DO_SUPABASE>
- `OPENAI_API_KEY` = <COLE_AQUI_SUA_OPENAI_API_KEY>
- (opcional) `READINESS_WINDOW_ATL` = `7`
- (opcional) `READINESS_WINDOW_CTL` = `42`

Salve, e rode um novo deploy.

## Local (`.env.local`)
Crie um arquivo `.env.local` na raiz do projeto (NÃO comitar) com:

```
NEXT_PUBLIC_SUPABASE_URL=<sua_url>
NEXT_PUBLIC_SUPABASE_ANON_KEY=<sua_anon_key>
OPENAI_API_KEY=<sua_openai_key>
READINESS_WINDOW_ATL=7
READINESS_WINDOW_CTL=42
```

## Supabase Edge Functions (se usar segredos nelas)
Defina segredos via CLI (exemplo):

```
supabase functions secrets set OPENAI_API_KEY=<sua_openai_key>
```

Depois publique suas funções normalmente.

## Rotação de chaves
- **OpenAI:** gere uma nova chave no painel e **revogue** a antiga. Atualize o Netlify e redeploy.
- **Supabase anon:** pode ser pública, mas se for exposta em repositórios, gere uma nova **anon key** nas configurações do projeto e atualize o Netlify.
