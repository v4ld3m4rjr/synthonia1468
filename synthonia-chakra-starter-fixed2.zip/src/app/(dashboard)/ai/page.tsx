export default function AIPage() {
  return (
    <section className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Análise com IA</h2>
      <div className="card">Pergunte aos seus dados + insights abaixo dos gráficos.</div>
    </section>
  )
}
