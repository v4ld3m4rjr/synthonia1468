export default function AnalyticsPage() {
  return (
    <section className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Analytics</h2>
      <div className="card mb-4">Seletor de variáveis e janela; gráficos reativos.</div>
      <div className="card">Exportar PDF/CSV; comentários por gráfico.</div>
    </section>
  )
}
